package com.example.expensetracker.db;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.*;

public class Migrations {

    public static void ensure() {
        try (Connection c = DB.get(); Statement st = c.createStatement()) {
            String sql = readResource("/schema.sql");
            st.executeUpdate("PRAGMA foreign_keys = ON;");
            for (String statement : sql.split(";\\n")) {
                String s = statement.trim();
                if (!s.isEmpty()) st.executeUpdate(s);
            }
        } catch (Exception e) {
            throw new RuntimeException("DB migration failed", e);
        }
    }

    private static String readResource(String path) throws IOException {
        try (InputStream is = Migrations.class.getResourceAsStream(path)) {
            if (is == null) throw new FileNotFoundException(path);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            return sb.toString();
        }
    }
}
