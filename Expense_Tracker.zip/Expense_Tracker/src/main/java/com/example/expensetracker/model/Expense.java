package com.example.expensetracker.model;

public class Expense {
    private final int id;
    private final String date;
    private final String description;
    private final double amount;
    private final int categoryId;
    private final String paymentMethod;
    private final String notes;

    public Expense(int id, String date, String description, double amount, int categoryId, String paymentMethod, String notes) {
        this.id = id;
        this.date = date;
        this.description = description;
        this.amount = amount;
        this.categoryId = categoryId;
        this.paymentMethod = paymentMethod;
        this.notes = notes;
    }

    public int getId() { return id; }
    public String getDate() { return date; }
    public String getDescription() { return description; }
    public double getAmount() { return amount; }
    public int getCategoryId() { return categoryId; }
    public String getPaymentMethod() { return paymentMethod; }
    public String getNotes() { return notes; }
}
