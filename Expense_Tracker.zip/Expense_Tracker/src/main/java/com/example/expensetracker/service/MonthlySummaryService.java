package com.example.expensetracker.service;

import com.example.expensetracker.dao.ExpenseDao;
import com.example.expensetracker.model.Expense;

import java.util.*;
import java.util.stream.Collectors;

public class MonthlySummaryService {

    private final ExpenseDao expenseDao;

    public MonthlySummaryService(ExpenseDao expenseDao) {
        this.expenseDao = expenseDao;
    }

    /**
     * Returns a map of category name -> total amount for a given month and year.
     *
     * @param year  the year
     * @param month the month (1-12)
     * @return map with category id as key and total amount as value
     */
    public Map<Integer, Double> getMonthlyTotalsByCategory(int year, int month) {
        List<Expense> expenses = expenseDao.byMonth(year, month);

        Map<Integer, Double> totals = new HashMap<>();
        for (Expense e : expenses) {
            totals.put(e.getCategoryId(), totals.getOrDefault(e.getCategoryId(), 0.0) + e.getAmount());
        }
        return totals;
    }

    /**
     * Returns total expenses for a given month and year.
     *
     * @param year  the year
     * @param month the month (1-12)
     * @return total amount
     */
    public double getTotalForMonth(int year, int month) {
        List<Expense> expenses = expenseDao.byMonth(year, month);
        double total = 0.0;
        for (Expense e : expenses) {
            total += e.getAmount();
        }
        return total;
    }

    /**
     * Returns expenses grouped by payment method for a given month.
     *
     * @param year  the year
     * @param month the month (1-12)
     * @return map payment method -> total amount
     */
    public Map<String, Double> getTotalsByPaymentMethod(int year, int month) {
        List<Expense> expenses = expenseDao.byMonth(year, month);
        Map<String, Double> totals = new HashMap<>();
        for (Expense e : expenses) {
            String method = e.getPaymentMethod();
            totals.put(method, totals.getOrDefault(method, 0.0) + e.getAmount());
        }
        return totals;
    }
}
