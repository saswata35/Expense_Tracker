package com.example.expensetracker.service;

import com.example.expensetracker.model.Expense;

import java.io.*;
import java.util.List;

public class CsvExporter {

    /**
     * Exports a list of expenses to a CSV file.
     *
     * @param expenses the list of expenses
     * @param file     the output CSV file
     * @throws IOException if an I/O error occurs
     */
    public static void exportExpenses(List<Expense> expenses, File file) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            // Write CSV header
            writer.write("ID,Date,Description,Amount,CategoryID,PaymentMethod,Notes");
            writer.newLine();

            // Write expense rows
            for (Expense e : expenses) {
                String line = String.format("%d,%s,%s,%.2f,%d,%s,%s",
                        e.getId(),
                        e.getDate(),
                        escapeCsv(e.getDescription()),
                        e.getAmount(),
                        e.getCategoryId(),
                        escapeCsv(e.getPaymentMethod()),
                        escapeCsv(e.getNotes()));
                writer.write(line);
                writer.newLine();
            }
        }
    }

    // Escape CSV fields that may contain commas or quotes
    private static String escapeCsv(String field) {
        if (field == null) return "";
        if (field.contains(",") || field.contains("\"") || field.contains("\n")) {
            field = field.replace("\"", "\"\"");
            return "\"" + field + "\"";
        }
        return field;
    }
}
