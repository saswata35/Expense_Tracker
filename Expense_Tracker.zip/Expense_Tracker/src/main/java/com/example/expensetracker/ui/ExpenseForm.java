package com.example.expensetracker.ui;

import com.example.expensetracker.dao.CategoryDao;
import com.example.expensetracker.dao.ExpenseDao;
import com.example.expensetracker.model.Category;
import com.example.expensetracker.model.Expense;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

import java.util.List;

public class ExpenseForm extends VBox {

    private final ExpenseDao expenseDao;
    private final CategoryDao categoryDao;

    private final DatePicker datePicker = new DatePicker();
    private final TextField descriptionField = new TextField();
    private final TextField amountField = new TextField();
    private final ComboBox<Category> categoryCombo = new ComboBox<>();
    private final TextField paymentField = new TextField();
    private final TextArea notesArea = new TextArea();
    private final Button saveButton = new Button("Save Expense");

    public ExpenseForm(ExpenseDao expenseDao, CategoryDao categoryDao) {
        this.expenseDao = expenseDao;
        this.categoryDao = categoryDao;

        setSpacing(10);
        GridPane form = new GridPane();
        form.setVgap(5);
        form.setHgap(10);

        form.add(new Label("Date:"), 0, 0);
        form.add(datePicker, 1, 0);

        form.add(new Label("Description:"), 0, 1);
        form.add(descriptionField, 1, 1);

        form.add(new Label("Amount:"), 0, 2);
        form.add(amountField, 1, 2);

        form.add(new Label("Category:"), 0, 3);
        form.add(categoryCombo, 1, 3);

        form.add(new Label("Payment Method:"), 0, 4);
        form.add(paymentField, 1, 4);

        form.add(new Label("Notes:"), 0, 5);
        form.add(notesArea, 1, 5);

        saveButton.setOnAction(e -> saveExpense());

        getChildren().addAll(form, saveButton);
        loadCategories();
    }

    private void loadCategories() {
        List<Category> categories = categoryDao.all();
        ObservableList<Category> observableCategories = FXCollections.observableArrayList(categories);
        categoryCombo.setItems(observableCategories);
        if (!categories.isEmpty()) categoryCombo.getSelectionModel().selectFirst();
    }

    private void saveExpense() {
        try {
            String date = datePicker.getValue().toString();
            String description = descriptionField.getText().trim();
            double amount = Double.parseDouble(amountField.getText().trim());
            Category category = categoryCombo.getSelectionModel().getSelectedItem();
            String payment = paymentField.getText().trim();
            String notes = notesArea.getText().trim();

            Expense expense = new Expense(0, date, description, amount, category.getId(), payment, notes);
            expenseDao.insert(expense);

            // Clear fields after saving
            descriptionField.clear();
            amountField.clear();
            paymentField.clear();
            notesArea.clear();
        } catch (Exception ex) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Failed to save expense: " + ex.getMessage());
            alert.showAndWait();
        }
    }
}
