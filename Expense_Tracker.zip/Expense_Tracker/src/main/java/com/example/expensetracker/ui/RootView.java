package com.example.expensetracker.ui;

import com.example.expensetracker.dao.CategoryDao;
import com.example.expensetracker.dao.ExpenseDao;
import com.example.expensetracker.service.MonthlySummaryService;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.StackPane;

import java.time.LocalDate;

public class RootView extends StackPane {

    private final CategoryDao categoryDao = new CategoryDao();
    private final ExpenseDao expenseDao = new ExpenseDao();
    private final MonthlySummaryService summaryService = new MonthlySummaryService(expenseDao);

    public RootView() {
        TabPane tabPane = new TabPane();

        // Category management tab
        CategoryPane categoryPane = new CategoryPane(categoryDao);
        Tab categoryTab = new Tab("Categories", categoryPane);

        // Expense form tab
        ExpenseForm expenseForm = new ExpenseForm(expenseDao, categoryDao);
        Tab expenseTab = new Tab("Expenses", expenseForm);

        // Analytics tab
        int year = LocalDate.now().getYear();
        int month = LocalDate.now().getMonthValue();
        AnalyticsPane analyticsPane = new AnalyticsPane(summaryService, year, month);
        Tab analyticsTab = new Tab("Analytics", analyticsPane);

        tabPane.getTabs().addAll(categoryTab, expenseTab, analyticsTab);
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        getChildren().add(tabPane);
    }
}
