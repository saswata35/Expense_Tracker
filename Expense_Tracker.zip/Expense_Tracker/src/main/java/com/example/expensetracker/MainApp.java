package com.example.expensetracker;

import com.example.expensetracker.db.Migrations;
import com.example.expensetracker.dao.CategoryDao;
import com.example.expensetracker.dao.ExpenseDao;
import com.example.expensetracker.model.Category;
import com.example.expensetracker.model.Expense;

import java.util.List;
import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        // Run DB migrations (create schema if not exists)
        Migrations.ensure();
        System.out.println("=== Expense Tracker (Console Version) ===");

        Scanner sc = new Scanner(System.in);
        CategoryDao categoryDao = new CategoryDao();
        ExpenseDao expenseDao = new ExpenseDao();

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. List Categories");
            System.out.println("2. Add Category");
            System.out.println("3. List Expenses");
            System.out.println("4. Add Expense");
            System.out.println("5. Exit");
            System.out.print("Choose option: ");

            String input = sc.nextLine();
            int choice;
            try {
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
                continue;
            }

            switch (choice) {
                case 1:
                    List<Category> categories = categoryDao.all();
                    System.out.println("Categories:");
                    for (Category c : categories) {
                        System.out.println(c.getId() + " - " + c.getName());
                    }
                    break;

                case 2:
                    System.out.print("Enter category name: ");
                    String name = sc.nextLine();
                    categoryDao.insert(name);
                    System.out.println("Category added!");
                    break;

                case 3:
                    List<Expense> expenses = expenseDao.all();
                    System.out.println("Expenses:");
                    for (Expense e : expenses) {
                        System.out.println(e.getId() + " | " + e.getDate() + " | " +
                                           e.getDescription() + " | $" + e.getAmount() +
                                           " | Category ID: " + e.getCategoryId());
                    }
                    break;

                case 4:
                    System.out.print("Enter date (yyyy-MM-dd): ");
                    String date = sc.nextLine();
                    System.out.print("Enter description: ");
                    String desc = sc.nextLine();
                    System.out.print("Enter amount: ");
                    double amount = Double.parseDouble(sc.nextLine());
                    System.out.print("Enter category id: ");
                    int catId = Integer.parseInt(sc.nextLine());
                    System.out.print("Enter payment method: ");
                    String method = sc.nextLine();
                    System.out.print("Enter notes: ");
                    String notes = sc.nextLine();

                    expenseDao.insert(date, desc, amount, catId, method, notes);
                    System.out.println("Expense added!");
                    break;

                case 5:
                    System.out.println("Goodbye!");
                    sc.close();
                    return;

                default:
                    System.out.println("Invalid option!");
            }
        }
    }
}
