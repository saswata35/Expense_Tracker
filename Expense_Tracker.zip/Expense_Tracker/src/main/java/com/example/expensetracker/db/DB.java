package com.example.expensetracker.db;


import java.nio.file.*;
import java.sql.*;


public class DB {
private static final String DB_FILE = System.getProperty("user.home") + "/.expense-tracker/expenses.db";
private static final String URL = "jdbc:sqlite:" + DB_FILE;


static {
try {
Files.createDirectories(Path.of(System.getProperty("user.home"), ".expense-tracker"));
} catch (Exception e) { throw new RuntimeException(e); }
}


public static Connection get() throws SQLException { return DriverManager.getConnection(URL); }
}