package com.example.expensetracker.ui;

import com.example.expensetracker.model.Category;
import com.example.expensetracker.service.MonthlySummaryService;
import javafx.collections.FXCollections;
import javafx.scene.chart.*;
import javafx.scene.layout.VBox;

import java.util.List;
import java.util.Map;

public class AnalyticsPane extends VBox {

    private final MonthlySummaryService summaryService;
    private final int year;
    private final int month;

    public AnalyticsPane(MonthlySummaryService summaryService, int year, int month) {
        this.summaryService = summaryService;
        this.year = year;
        this.month = month;

        setSpacing(20);

        // Example charts
        PieChart pieChart = createCategoryPieChart();
        BarChart<String, Number> barChart = createPaymentBarChart();

        getChildren().addAll(pieChart, barChart);
    }

    private PieChart createCategoryPieChart() {
        Map<Integer, Double> totalsByCategory = summaryService.getMonthlyTotalsByCategory(year, month);

        PieChart.Data[] data = totalsByCategory.entrySet().stream()
                .map(e -> new PieChart.Data("Category " + e.getKey(), e.getValue()))
                .toArray(PieChart.Data[]::new);

        PieChart pieChart = new PieChart(FXCollections.observableArrayList(data));
        pieChart.setTitle("Expenses by Category");
        return pieChart;
    }

    private BarChart<String, Number> createPaymentBarChart() {
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Payment Method");
        yAxis.setLabel("Amount");

        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle("Expenses by Payment Method");

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Monthly Totals");

        Map<String, Double> totalsByPayment = summaryService.getTotalsByPaymentMethod(year, month);
        for (Map.Entry<String, Double> entry : totalsByPayment.entrySet()) {
            series.getData().add(new XYChart.Data<>(entry.getKey(), entry.getValue()));
        }

        barChart.getData().add(series);
        return barChart;
    }
}
