package com.example.expensetracker.ui;

import com.example.expensetracker.dao.CategoryDao;
import com.example.expensetracker.model.Category;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

public class CategoryPane extends VBox {

    private final CategoryDao categoryDao;
    private final ObservableList<Category> categories = FXCollections.observableArrayList();
    private final ListView<Category> listView = new ListView<>(categories);
    private final TextField nameField = new TextField();
    private final Button addButton = new Button("Add Category");

    public CategoryPane(CategoryDao categoryDao) {
        this.categoryDao = categoryDao;
        setSpacing(10);

        listView.setCellFactory(param -> new ListCell<Category>() {
            @Override
            protected void updateItem(Category item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getName());
            }
        });

        addButton.setOnAction(e -> addCategory());

        getChildren().addAll(new Label("Categories:"), listView, nameField, addButton);
        refreshCategories();
    }

    private void refreshCategories() {
        categories.setAll(categoryDao.all());
    }

    private void addCategory() {
        String name = nameField.getText().trim();
        if (!name.isEmpty()) {
            categoryDao.insert(name);
            nameField.clear();
            refreshCategories();
        }
    }
}
