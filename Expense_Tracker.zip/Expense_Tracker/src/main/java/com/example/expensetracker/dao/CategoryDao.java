package com.example.expensetracker.dao;


import com.example.expensetracker.db.DB;
import com.example.expensetracker.model.Category;
import java.sql.*;
import java.util.*;


public class CategoryDao {
public List<Category> all() {
try (Connection c = DB.get(); PreparedStatement ps = c.prepareStatement("SELECT id, name FROM categories ORDER BY name")) {
ResultSet rs = ps.executeQuery();
List<Category> list = new ArrayList<>();
while (rs.next()) list.add(new Category(rs.getInt(1), rs.getString(2)));
return list;
} catch (SQLException e) { throw new RuntimeException(e); }
}


public Category insert(String name) {
try (Connection c = DB.get(); PreparedStatement ps = c.prepareStatement("INSERT INTO categories(name) VALUES(?)", Statement.RETURN_GENERATED_KEYS)) {
ps.setString(1, name);
ps.executeUpdate();
try (ResultSet keys = ps.getGeneratedKeys()) {
if (keys.next()) return new Category(keys.getInt(1), name);
}
throw new SQLException("No generated key");
} catch (SQLException e) { throw new RuntimeException(e); }
}
}