package com.example.expensetracker.dao;

import com.example.expensetracker.db.DB;
import com.example.expensetracker.model.Expense;
import java.sql.*;
import java.util.*;

public class ExpenseDao {

    public Expense insert(Expense e) {
        String sql = "INSERT INTO expenses(date, description, amount, category_id, payment_method, notes) VALUES(?,?,?,?,?,?)";
        try (Connection c = DB.get(); PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, e.getDate());
            ps.setString(2, e.getDescription());
            ps.setDouble(3, e.getAmount());
            ps.setInt(4, e.getCategoryId());
            ps.setString(5, e.getPaymentMethod());
            ps.setString(6, e.getNotes());

            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    return new Expense(
                        keys.getInt(1),
                        e.getDate(),
                        e.getDescription(),
                        e.getAmount(),
                        e.getCategoryId(),
                        e.getPaymentMethod(),
                        e.getNotes()
                    );
                }
            }
            throw new SQLException("No generated key");
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }

    public List<Expense> all() {
        String sql = "SELECT id, date, description, amount, category_id, payment_method, notes FROM expenses ORDER BY date DESC, id DESC";
        try (Connection c = DB.get(); PreparedStatement ps = c.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            List<Expense> list = new ArrayList<>();
            while (rs.next()) list.add(map(rs));
            return list;
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }

    public List<Expense> byMonth(int year, int month) {
        String ym = String.format("%04d-%02d", year, month);
        String sql = "SELECT id, date, description, amount, category_id, payment_method, notes " +
                     "FROM expenses WHERE strftime('%Y-%m', date) = ? ORDER BY date DESC, id DESC";
        try (Connection c = DB.get(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, ym);
            ResultSet rs = ps.executeQuery();
            List<Expense> list = new ArrayList<>();
            while (rs.next()) list.add(map(rs));
            return list;
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }

    private Expense map(ResultSet rs) throws SQLException {
        return new Expense(
            rs.getInt("id"),
            rs.getString("date"),
            rs.getString("description"),
            rs.getDouble("amount"),
            rs.getInt("category_id"),
            rs.getString("payment_method"),
            rs.getString("notes")
        );
    }

    // 👇 Fixed version of insert with parameters
    public Expense insert(String date, String desc, double amount, int catId, String method, String notes) {
        Expense e = new Expense(0, date, desc, amount, catId, method, notes);
        return insert(e);
    }
}
