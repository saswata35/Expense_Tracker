-- Enable foreign key support
PRAGMA foreign_keys = ON;

-- ===========================
-- Categories Table
-- ===========================
CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
);

-- ===========================
-- Expenses Table
-- ===========================
CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL, -- ISO format yyyy-MM-dd
    description TEXT,
    amount REAL NOT NULL CHECK (amount >= 0),
    category_id INTEGER NOT NULL,
    payment_method TEXT, -- e.g., Cash, Card, UPI
    notes TEXT,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT
);

-- ===========================
-- Seed Initial Categories
-- ===========================
INSERT OR IGNORE INTO categories(name) VALUES
    ('Food'),
    ('Transport'),
    ('Housing'),
    ('Health'),
    ('Entertainment'),
    ('Utilities'),
    ('Misc');
